# Update 0.6.3-test

This archive carries forward the existing LUNARVOIDSMP project and the current GitHub workflow changes, with the Maven artifact version advanced to `0.6.3-test`. This is a source project, not a verified build. The GitHub Actions Maven build has been failing, so compile and test before installing on a live server.
